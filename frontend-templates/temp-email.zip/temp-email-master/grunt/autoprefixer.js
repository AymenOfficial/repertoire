// Browser-based preview task
module.exports = {
  preview: {
    options: {
      browsers: ['last 6 versions', 'ie 9']
    },
    src: 'preview/css/preview.css'
  }
}
